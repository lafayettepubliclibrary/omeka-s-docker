<?php declare(strict_types=1);

/*
 * Copyright 2015-2021 Daniel Berthereau
 *
 * This software is governed by the CeCILL license under French law and abiding
 * by the rules of distribution of free software. You can use, modify and/or
 * redistribute the software under the terms of the CeCILL license as circulated
 * by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
 *
 * As a counterpart to the access to the source code and rights to copy, modify
 * and redistribute granted by the license, users are provided only with a
 * limited warranty and the software’s author, the holder of the economic
 * rights, and the successive licensors have only limited liability.
 *
 * In this respect, the user’s attention is drawn to the risks associated with
 * loading, using, modifying and/or developing or reproducing the software by
 * the user in light of its specific status of free software, that may mean that
 * it is complicated to manipulate, and that also therefore means that it is
 * reserved for developers and experienced professionals having in-depth
 * computer knowledge. Users are therefore encouraged to load and test the
 * software’s suitability as regards their requirements in conditions enabling
 * the security of their systems and/or data to be ensured and, more generally,
 * to use and operate it in the same conditions as regards security.
 *
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 */

namespace IiifServer\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Omeka\Stdlib\Message;

class NoopServerController extends AbstractActionController
{
    use IiifServerControllerTrait;

    /**
     * @var string
     */
    protected $routeInfo = 'imageserver/info';

    public function infoAction()
    {
        $resource = $this->fetchResource('media');
        if (!$resource) {
            return $this->jsonError(new Message(
                'Media "%s" not found.', // @translate
                $this->params('id')
            ), \Laminas\Http\Response::STATUS_CODE_404);
        }

        if (!$this->isImageResource($resource)) {
            $params = $this->params()->fromRoute();
            $params['resource'] = $resource;
            return $this->forward()->dispatch(\IiifServer\Controller\MediaController::class, $params);
        }

        return $this->jsonError(new Message(
            'The media server is unavailable for resource "%s".', // @translate
            $this->params('id')
        ), \Laminas\Http\Response::STATUS_CODE_503);
    }

    public function fetchAction()
    {
        $resource = $this->fetchResource('media');
        if (!$resource) {
            return $this->viewError(new Message(
                'Media "%s" not found.', // @translate
                $this->params('id')
            ), \Laminas\Http\Response::STATUS_CODE_404);
        }
        return $this->viewError(new Message(
            'The media server is unavailable for resource "%s".', // @translate
            $this->params('id')
        ), \Laminas\Http\Response::STATUS_CODE_503);
    }

    public function placeholderAction()
    {
        $response = $this->getResponse();

        // TODO Manage other placeholders or use a setting.
        $placeholder = 'thumbnails/default.png';

        // Header for CORS, required for access.
        $response->getHeaders()
            ->addHeaderLine('access-control-allow-origin', '*')
            ->addHeaderLine('Content-Type', 'image/png');

        // TODO This is a local file (normal server): use 200.

        // Redirect (302/307) to the url of the file.
        $assetUrl = $this->viewHelpers()->get('assetUrl')->__invoke($placeholder, 'Omeka');
        return $this->redirect()->toUrl($assetUrl);
    }
}
