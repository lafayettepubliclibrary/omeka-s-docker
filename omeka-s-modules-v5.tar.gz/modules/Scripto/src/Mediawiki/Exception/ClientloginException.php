<?php
namespace Scripto\Mediawiki\Exception;

class ClientloginException extends \RuntimeException
{
}
