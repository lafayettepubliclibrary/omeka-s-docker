<?php
namespace Scripto\Mediawiki\Exception;

class ProtectException extends \RuntimeException
{
}
