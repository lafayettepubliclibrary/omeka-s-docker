<?php
namespace Scripto\Mediawiki\Exception;

class EditException extends \RuntimeException
{
}
