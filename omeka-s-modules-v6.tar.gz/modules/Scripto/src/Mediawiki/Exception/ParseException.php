<?php
namespace Scripto\Mediawiki\Exception;

class ParseException extends \RuntimeException
{
}
