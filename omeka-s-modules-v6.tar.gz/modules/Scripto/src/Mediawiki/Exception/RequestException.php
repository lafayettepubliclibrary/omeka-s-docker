<?php
namespace Scripto\Mediawiki\Exception;

class RequestException extends \RuntimeException
{
}
