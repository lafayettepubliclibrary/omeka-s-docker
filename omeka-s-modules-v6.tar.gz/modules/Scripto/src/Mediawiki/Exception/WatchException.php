<?php
namespace Scripto\Mediawiki\Exception;

class WatchException extends \RuntimeException
{
}
