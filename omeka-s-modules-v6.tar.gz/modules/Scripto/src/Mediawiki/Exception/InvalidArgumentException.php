<?php
namespace Scripto\Mediawiki\Exception;

class InvalidArgumentException extends \InvalidArgumentException
{
}
