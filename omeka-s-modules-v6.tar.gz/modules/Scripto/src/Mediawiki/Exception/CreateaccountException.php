<?php
namespace Scripto\Mediawiki\Exception;

class CreateaccountException extends \RuntimeException
{
}
