<?php
namespace Scripto\Mediawiki\Exception;

class QueryException extends \RuntimeException
{
}
