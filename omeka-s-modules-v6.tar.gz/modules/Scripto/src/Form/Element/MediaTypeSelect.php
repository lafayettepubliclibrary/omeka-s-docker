<?php
namespace Scripto\Form\Element;

use Laminas\Form\Element\Select;

class MediaTypeSelect extends Select
{
}
