COinS module for Omeka S
========================

This [Omeka S] module is a rewrite of [COinS plugin for Omeka] and
intends to provide the same features as the original plugin.

Build status
------------

[![Build Status](https://travis-ci.org/biblibre/omeka-s-module-Coins.svg?branch=master)](https://travis-ci.org/biblibre/omeka-s-module-Coins)

[COinS plugin for Omeka]: http://omeka.org/add-ons/plugins/coins/
[Omeka S]: https://github.com/omeka/omeka-s
