<?php

namespace Coins;

return [
    'view_helpers' => [
        'invokables' => [
            'coins' => View\Helper\Coins::class,
        ],
    ],
];
