# Omeka2Importer

Import items from an Omeka 2 site into Omeka S

See the [Omeka S user manual](http://omeka.org/s/docs/user-manual/modules/omeka2importer/) for user documentation.

## Installation

See general end user documentation for [Installing a module](http://omeka.org/s/docs/user-manual/modules/#installing-modules)
