# Sharing
Omeka S module for sharing content via 1) Social Media and 2) Embedding Omeka S content in other sites

See the [Omeka S user manual](http://omeka.org/s/docs/user-manual/modules/sharing/) for user documentation.

## Installation

See general end user documentation for [Installing a module](http://omeka.org/s/docs/user-manual/modules/#installing-modules)
