<?php
return [
    'view_manager' => [
        'template_map' => [
            'config_form' => __DIR__ . '/../view/siteslugassubdomain/config.phtml',
        ],
    ],
];
