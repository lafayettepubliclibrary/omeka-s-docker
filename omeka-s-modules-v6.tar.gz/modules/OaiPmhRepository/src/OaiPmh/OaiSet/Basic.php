<?php declare(strict_types=1);
namespace OaiPmhRepository\OaiPmh\OaiSet;

class Basic extends AbstractOaiSet
{
}
