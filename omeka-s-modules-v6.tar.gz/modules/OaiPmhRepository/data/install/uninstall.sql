SET foreign_key_checks = 0;
DROP TABLE IF EXISTS oai_pmh_repository_token;
SET foreign_key_checks = 1;
